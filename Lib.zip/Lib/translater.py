import tkinter as tk
from tkinter import ttk
from indic_transliteration import sanscript

class TransliteratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Transliteration to Nepali")
        
        # Set the window size to 600x400
        self.root.geometry("600x400")
        
        self.create_widgets()

    def create_widgets(self):
        # Create a label
        label = ttk.Label(self.root, text="Enter text to transliterate to Nepali:")
        label.pack(pady=10)
        
        # Create an entry field
        self.text_entry = ttk.Entry(self.root, width=40)
        self.text_entry.pack()
        self.text_entry.bind('<Return>', self.transliterate_text_event)
        
        # Create a button to trigger transliteration
        transliterate_button = ttk.Button(self.root, text="Transliterate", command=self.transliterate_text)
        transliterate_button.pack(pady=10)
        
        # Create a "Clear" button
        clear_button = ttk.Button(self.root, text="Clear", command=self.clear_text)
        clear_button.pack(pady=10)
        
        # Create a text widget to display the transliterated text
        self.result_text = tk.Text(self.root, wrap=tk.WORD, height=10, width=50)
        self.result_text.pack()

    def transliterate_text_event(self, event):
        self.transliterate_text()

    def transliterate_text(self):
        text_to_transliterate = self.text_entry.get()
        if text_to_transliterate:
            try:
                transliterated_text = sanscript.transliterate(text_to_transliterate, sanscript.ITRANS, "devanagari")
                # Clear the text widget
                self.result_text.delete("1.0", tk.END)
                # Insert the transliterated text into the text widget
                self.result_text.insert(tk.END, f"Transliteration in Nepali: {transliterated_text}")
            except Exception as e:
                # Clear the text widget
                self.result_text.delete("1.0", tk.END)
                self.result_text.insert(tk.END, f"An error occurred: {str(e)}")
        else:
            # Clear the text widget
            self.result_text.delete("1.0", tk.END)
            self.result_text.insert(tk.END, "Please enter text to transliterate.")
    
    def clear_text(self):
        # Clear the text widget
        self.result_text.delete("1.0", tk.END)